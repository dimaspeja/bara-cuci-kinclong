@extends('layouts.app')

@section('title', 'Masuk · Bara Cuci Kinclong')

@section('content')
    <div class="mx-auto max-w-sm rounded-xl border border-slate-200 bg-white p-6">
        <h1 class="text-xl font-bold">Masuk ke Akun</h1>

        <form method="POST" action="{{ route('login.attempt') }}" class="mt-5 space-y-4">
            @csrf
            <div>
                <label for="email" class="text-sm font-medium">Email</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus
                       placeholder="nama@email.com"
                       class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-sky-500 focus:outline-none">
            </div>
            <div>
                <label for="password" class="text-sm font-medium">Kata sandi</label>
                <input id="password" name="password" type="password" required
                       class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-sky-500 focus:outline-none">
            </div>
            <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" name="remember" value="1" class="rounded border-slate-300"> Ingat saya
            </label>
            <button class="w-full rounded-md bg-sky-600 py-2 font-medium text-white hover:bg-sky-700">Masuk</button>
        </form>

        @if (config('services.google.client_id'))
            <div class="my-5 flex items-center gap-3 text-xs text-slate-400">
                <span class="h-px flex-1 bg-slate-200"></span> atau <span class="h-px flex-1 bg-slate-200"></span>
            </div>
            <a href="{{ route('google.redirect') }}"
               class="flex w-full items-center justify-center gap-2 rounded-md border border-slate-300 py-2 text-sm font-medium hover:bg-slate-50">
                <span class="font-bold text-sky-600">G</span> Masuk dengan Google
            </a>
        @endif

        <p class="mt-5 text-center text-sm text-slate-500">
            Belum punya akun? <a href="{{ route('register') }}" class="text-sky-600 hover:underline">Daftar</a>
        </p>
    </div>
@endsection
