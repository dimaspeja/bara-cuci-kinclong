<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Bara Cuci Kinclong'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-800 antialiased">
<?php ($authUser = auth()->user()); ?>
<header class="border-b border-slate-200 bg-white">
    <nav class="mx-auto flex max-w-5xl flex-wrap items-center gap-x-5 gap-y-2 px-4 py-3 text-sm">
        <a href="<?php echo e(route('landing')); ?>" class="mr-2 text-lg font-bold text-sky-600">Bara Cuci Kinclong</a>
        <a href="<?php echo e(route('services')); ?>" class="hover:text-sky-600">Layanan</a>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($authUser && ! $authUser->role?->isBackOffice()): ?>
            <a href="<?php echo e(route('home')); ?>" class="hover:text-sky-600">Beranda</a>
            <a href="<?php echo e(route('bookings.create')); ?>" class="hover:text-sky-600">Booking</a>
            <a href="<?php echo e(route('bookings.index')); ?>" class="hover:text-sky-600">Booking Saya</a>
            <a href="<?php echo e(route('vehicles.index')); ?>" class="hover:text-sky-600">Kendaraan</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($authUser && $authUser->role?->isBackOffice()): ?>
            <a href="/admin" class="font-medium text-sky-600">Panel Admin</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($authUser->isAdmin()): ?>
                <a href="<?php echo e(route('bookings.create')); ?>" class="hover:text-sky-600">Booking</a>
                <a href="<?php echo e(route('bookings.index')); ?>" class="hover:text-sky-600">Booking Saya</a>
                <a href="<?php echo e(route('vehicles.index')); ?>" class="hover:text-sky-600">Kendaraan</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="ml-auto flex items-center gap-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <span class="text-slate-500"><?php echo e($authUser->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="rounded-md border border-slate-300 px-3 py-1 hover:bg-slate-100">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="hover:text-sky-600">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="rounded-md bg-sky-600 px-3 py-1 text-white hover:bg-sky-700">Daftar</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </nav>
</header>

<main class="mx-auto max-w-5xl px-4 py-8">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
        <div class="mb-5 rounded-md border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
        <div class="mb-5 rounded-md border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
            <ul class="list-disc space-y-0.5 pl-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="py-8 text-center text-xs text-slate-400">
    Bara Cuci Kinclong · Bersih · Cepat · Terpercaya
</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bara-cuci-kinclong\resources\views/layouts/app.blade.php ENDPATH**/ ?>