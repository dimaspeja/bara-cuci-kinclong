<?php $__env->startSection('title', 'Layanan · Bara Cuci Kinclong'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold">Daftar layanan</h1>
    <p class="text-sm text-slate-500">Harga bersifat informasi. Pembayaran dilakukan langsung di lokasi.</p>

    <div class="mt-6 grid gap-4 sm:grid-cols-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex flex-col rounded-xl border border-slate-200 bg-white p-5">
                <h2 class="text-lg font-semibold"><?php echo e($service->name); ?></h2>
                <p class="mt-1 flex-1 text-sm text-slate-500"><?php echo e($service->description); ?></p>
                <div class="mt-4 flex items-end justify-between">
                    <div>
                        <p class="text-xl font-bold text-sky-600"><?php echo e($service->priceLabel()); ?></p>
                        <p class="text-xs text-slate-400">± <?php echo e($service->duration_minutes); ?> menit</p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! auth()->user()->role?->isBackOffice() || auth()->user()->isAdmin()): ?>
                            <a href="<?php echo e(route('bookings.create', ['service' => $service->id])); ?>"
                               class="rounded-md bg-sky-600 px-4 py-1.5 text-sm text-white hover:bg-sky-700">Booking</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="rounded-md border border-sky-600 px-4 py-1.5 text-sm text-sky-600 hover:bg-sky-50">Masuk untuk booking</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-slate-500">Belum ada layanan.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bara-cuci-kinclong\resources\views/services.blade.php ENDPATH**/ ?>