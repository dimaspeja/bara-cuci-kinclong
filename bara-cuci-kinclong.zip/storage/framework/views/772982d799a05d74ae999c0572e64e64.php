<?php $__env->startSection('title', 'Daftar · Bara Cuci Kinclong'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mx-auto max-w-sm rounded-xl border border-slate-200 bg-white p-6">
        <h1 class="text-xl font-bold">Buat Akun</h1>

        <form method="POST" action="<?php echo e(route('register.store')); ?>" class="mt-5 space-y-4">
            <?php echo csrf_field(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [
                ['name', 'Nama lengkap', 'text', true],
                ['email', 'Email', 'email', true],
                ['phone', 'Nomor telepon / WhatsApp (opsional)', 'tel', false],
                ['password', 'Kata sandi (min. 8 karakter)', 'password', true],
                ['password_confirmation', 'Ulangi kata sandi', 'password', true],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$field, $label, $type, $required]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label for="<?php echo e($field); ?>" class="text-sm font-medium"><?php echo e($label); ?></label>
                    <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="<?php echo e($type); ?>"
                           <?php if($type !== 'password'): ?> value="<?php echo e(old($field)); ?>" <?php endif; ?>
                           <?php if($required): ?> required <?php endif; ?>
                           class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-sky-500 focus:outline-none">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <button class="w-full rounded-md bg-sky-600 py-2 font-medium text-white hover:bg-sky-700">Daftar</button>
        </form>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(config('services.google.client_id')): ?>
            <div class="my-5 flex items-center gap-3 text-xs text-slate-400">
                <span class="h-px flex-1 bg-slate-200"></span> atau <span class="h-px flex-1 bg-slate-200"></span>
            </div>
            <a href="<?php echo e(route('google.redirect')); ?>"
               class="flex w-full items-center justify-center gap-2 rounded-md border border-slate-300 py-2 text-sm font-medium hover:bg-slate-50">
                <span class="font-bold text-sky-600">G</span> Daftar dengan Google
            </a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <p class="mt-5 text-center text-sm text-slate-500">
            Sudah punya akun? <a href="<?php echo e(route('login')); ?>" class="text-sky-600 hover:underline">Masuk</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bara-cuci-kinclong\resources\views/auth/register.blade.php ENDPATH**/ ?>