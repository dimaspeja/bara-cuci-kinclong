<?php $__env->startSection('title', 'Beranda · Bara Cuci Kinclong'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold">Halo, <?php echo e(auth()->user()->name); ?> 👋</h1>
    <p class="text-sm text-slate-500">Atur booking cuci kendaraan Anda dari sini.</p>

    <div class="mt-6 grid gap-4 sm:grid-cols-3">
        <div class="rounded-xl border border-slate-200 bg-white p-4">
            <p class="text-xs text-slate-500">Booking aktif</p>
            <p class="text-2xl font-bold"><?php echo e($upcoming->count()); ?></p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-4">
            <p class="text-xs text-slate-500">Cuci selesai</p>
            <p class="text-2xl font-bold"><?php echo e($completedCount); ?></p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-4">
            <p class="text-xs text-slate-500">Kendaraan tersimpan</p>
            <p class="text-2xl font-bold"><?php echo e($vehicleCount); ?></p>
        </div>
    </div>

    <div class="mt-6 flex flex-wrap gap-3">
        <a href="<?php echo e(route('bookings.create')); ?>" class="rounded-md bg-sky-600 px-5 py-2 text-white hover:bg-sky-700">Booking baru</a>
        <a href="<?php echo e(route('vehicles.index')); ?>" class="rounded-md border border-slate-300 bg-white px-5 py-2 hover:bg-slate-50">Kelola kendaraan</a>
    </div>

    <section class="mt-8">
        <h2 class="text-lg font-semibold">Booking berjalan</h2>
        <div class="mt-3 space-y-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white p-4">
                    <div>
                        <p class="font-medium"><?php echo e($booking->service->name); ?>

                            <span class="text-xs text-slate-400">· <?php echo e($booking->code); ?></span></p>
                        <p class="text-sm text-slate-500">
                            <?php echo e($booking->booking_date->translatedFormat('l, d M Y')); ?>, <?php echo e($booking->timeLabel()); ?>

                            · <?php echo e($booking->vehicle->plate_number); ?>

                        </p>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $booking->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($booking->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada booking berjalan.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bara-cuci-kinclong\resources\views/home.blade.php ENDPATH**/ ?>