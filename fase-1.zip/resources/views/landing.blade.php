@extends('layouts.app')

@section('content')
    <section class="rounded-2xl bg-gradient-to-br from-sky-600 to-sky-800 px-6 py-14 text-white sm:px-12">
        <p class="text-sm uppercase tracking-widest text-sky-200">Carwash &amp; Autocare</p>
        <h1 class="mt-2 text-3xl font-bold sm:text-4xl">Mobil bersih, perjalanan lebih nyaman.</h1>
        <p class="mt-3 max-w-xl text-sky-100">
            Pilih layanan, tentukan jadwal, dan datang saat giliran Anda. Tanpa antre panjang.
        </p>
        <div class="mt-6 flex flex-wrap gap-3">
            @auth
                @if (auth()->user()->role?->isBackOffice())
                    <a href="/admin" class="rounded-md bg-white px-5 py-2 font-medium text-sky-700 hover:bg-sky-50">Buka Panel Admin</a>
                @else
                    <a href="{{ route('home') }}" class="rounded-md bg-white px-5 py-2 font-medium text-sky-700 hover:bg-sky-50">Ke Beranda</a>
                @endif
            @else
                <a href="{{ route('register') }}" class="rounded-md bg-white px-5 py-2 font-medium text-sky-700 hover:bg-sky-50">Daftar</a>
                <a href="{{ route('login') }}" class="rounded-md border border-white/60 px-5 py-2 hover:bg-white/10">Masuk</a>
            @endauth
        </div>
    </section>
@endsection
