<?php

namespace App\Http\Controllers;

// FASE 1: hanya landing dan beranda sederhana.
// Fase 2 menambah daftar layanan, Fase 6 menambah ringkasan booking.
class HomeController extends Controller
{
    public function landing()
    {
        return view('landing');
    }

    public function home()
    {
        return view('home');
    }
}
